slofil: dialog
{
  label="Slope Files Editor";
  :row
  {
  cildren_alignment=center;
  :boxed_radio_column
    {
    key="slotype";
    value="fill";
    :radio_button
      {
      key="fill";
      label="Fill Slope Files...";
      mnemonic="F";
      }
    :radio_button
      {
      key="cut";
      label="Cut Slope Files ...";
      mnemonic="C";
      }
    }
  :image_button
    {
    key="gavran";
    width=12;
    height=4;      
    color=-15;
    fixed_height=true;
    }
  }
  :boxed_radio_row
    {
    key="task";
    value="newslo";
    :radio_button
      {
      key="newslo";
      label="NEW";
      mnemonic="N";
      }
    :radio_button
      {
      key="edislo";
      label="EDIT";
      mnemonic="E";
      }
    }
  ok_cancel;  
}

sloedit : dialog
{
  label = "Slope Editor";
  :text
    {
    key="sloedlbl";
    value="";
    }
  :row
  {
  :column
    {
    fixed_height=true;
    :image_button
      {
      key="gavran";
      width=12;
      height=4;
      color=-15;
      }
    :button
      {
      key="add";
      label="ADD... ";
      mnemonic="A";
//      fixed_width=true;
      }
    :button
      {
      key="ins";
      label="INS... ";
      mnemonic="I";
//      fixed_width=true;
      }
    :button
      {
      key="del";
      label="DEL    ";
      mnemonic="D";
//      fixed_width=true;
      }
    :button
      {
      key="edit";
      label="EDIT...";
      mnemonic="E";
//      fixed_width=true;
      }
    }
  :list_box
    {
    key="seg";
    label="Length         Slope (1: )";
    tabs="9";
    width=20;
    }
  }
  ok_cancel;
}

sloseg:dialog
{
  label= "Slope Segment Editor";
  :edit_box
    {
    key="len";
    label="     Length:";
    edit_width=10;    
    }
  :edit_box
    {
    key="slo";
    label="Slope (1: ):";
    edit_width=10;
    }
  ok_cancel;
}

surface: dialog
{
label="Surface Editor";
:row
  {
  :boxed_column
    {
    :button
      {
      key="new";
      label="  NEW<<<  ";
      mnemonic="N";
      }
    :boxed_radio_column
      {
      key="filter";
      value="L";
      :radio_button
       {
        key="L";
        label="Layer";
        }
      :radio_button
        {
        key="LS";
        label="Layer + Select";
        }
      :radio_button
       {
        key="LB";
        label="Layer & BYL-color";
        }
      :radio_button
        {
        key="LC";
        label="Layer & Color";
        }
      :radio_button
        {
        key="SLC";
        label="Layer & Color + Select";
        }
      }
    }
  :column
    {
    :image_button
      {
      key="gavran";
      width=10;
      height=3;
      color=-15;
      alignment=centered;
      fixed_width=true;
      }
    :text
      {
      key="";
      value="";
      }
    :button
      {
      key="show";
      label=" LIST...  ";
      mnemonic="L";
      }
    :button
      {
      key="area";
      label=" AREA...  ";
      mnemonic="A";
      }
    :button
      {
      key="copy";
      label=" COPY...  ";
      mnemonic="C";
      }
    :button
      {
      key="join";
      label=" JOIN...  ";
      mnemonic="J";
      }
    }
  }
ok_cancel;
}

surlist:dialog
{
label="Surface Report by Triangles";
:concatenation
  {
  :text_part
    {
    key="name1";
    label="File name: ";
    }
  :text_part
    {
    key="name2";
    label="                                                        ";
    }
  }
  :text
    {
    key="space";
    label= " ";
    }
:list_box
  {
  key="list";
  label="";
  tabs="5 25 31";
  width=60;
  }
ok_cancel;
}

main: dialog
{
label="Sloped surfaces";
:text
  {
  key="tittle";
  label="                                    ";
  alignment=centered;
  }
:row
{
children_alignment=bottom;
:column
{
:boxed_radio_column
  {
  key="side";
  value="right";
  label="Side";
  :radio_button
    {
    key="right";
    label="Right";
    }
  :radio_button
    {
    key="left";
    label="Left";
    }
  }
:boxed_radio_column
  {
  key="correct";
  value="no";
  label="Correction at changes";
  :radio_button
    {
    key="yes";
    label="Yes";
    }
  :radio_button
    {
    key="no";
    label="No";
    }
  }
:boxed_column
  {
  key="skip";
  label="Face to skip";
  :toggle
    {
    key="first";
    label="First";
    }
  :toggle
    {
    key="last";
    label="Last";
    }
  }
}
:column
{
:image_button
  {
  key="gavran";
  width=12;
  height=5;
  color=-15;
  fixed_height=true;
  alignment=right;
  fixed_height=true;
  fixed_width=true;
  }
:boxed_column
  {
  fixed_height=true;
  :boxed_radio_column
    {
    key="string";
    value="syes";
    label="Outer string";
    fixed_height=true;
    :radio_button
      {
      key="syes";
      label="Yes";
      }
    :radio_button
      {
      key="sno";
      label="No";
      }
    }
  :popup_list
    {
    key="popla";
    label="Layer";
    edit_width=20;
    }
  }
}
}
ok_cancel;
}

const:dialog
{
label="Constant slope options";
:row
{
children_alignment=top;
children_fixed_height=true;
:radio_column
  {
  key="option";
  value= "grade";
  spacer;
  :radio_button
    {
    key="grade";
    label="Grade";
    }
  :radio_button
    {
    key="slope";
    label="Slope";
    }
  :radio_button
    {
    key="horizontal";
    label="Horizontal";
    }
  :radio_button
    {
    key="vertical";
    label="Vertical";
    }
  }
:column
{
children_fixed_height=true;
:edit_box
  {
  key="gralen";
  label="Length:";
  value="0.00";
  }
:edit_box
  {
  key="slolen";
  label="Length:";
  value="0.00";
  }
:edit_box
  {
  key="horlen";
  label="Length:";
  value="0.00";
  }
:edit_box
  {
  key="verlen";
  label="Length:";
  value="0.00";
  }
}
:column
{
children_alignment=right;
fixed_height=true;
:edit_box
  {
  key="gradeslo";
  label=" Grade (%):";
  value="0.00";
  edit_width=8;
  }
:edit_box
  {
  key="slopeslo";
  label=" Slope (1: ):";
  value="0.00";
  edit_width=8;
  }
:image_button
  {
  key="gavran";
  width=12;
  height=4;
  color=-15;
  alignment=right;
  fixed_height=true;
  fixed_width=true;
  }
}
}
ok_cancel;
}

slope:dialog
{
label="Daylight line options";
:boxed_column
  {
  fixed_height=true;
  :boxed_radio_column
    {
    key="daylight";
    value="dyes";
    label="Daylight marking";
    fixed_height=true;
    :radio_button
      {
      key="dyes";
      label="Yes";
      }
    :radio_button
      {
      key="dno";
      label="No";
      }
    }
  :popup_list
    {
    key="poplad";
    label="Layer";
    edit_width=20;
    }
  }
ok_cancel;
}

di2twist:dialog
{
label="Twisted surface grades";
:edit_box
  {
  key="slope1";
  label="First grade (%):";
  value="0.00";
  edit_width=12;
  }
:edit_box
  {
  key="slope2";
  label="Last grade (%):";
  value="0.00";
  edit_width=12;
  }
:edit_box
  {
  key="width";
  label="            Width:";
  value="0.00";
  edit_width=12;
  }
ok_cancel;
}

di2inters:dialog
{
label="Intersecting grades";
:edit_box
  {
  key="lslope";
  label="     First grade (%):";
  value="1.00";
  edit_width=12;
  }
:edit_box
  {
  key="rslope";
  label="Second grade (%):";
  value="1.00";
  edit_width=12;
  }
ok_cancel;
}

warint:dialog
{
  label="WARNING !";
  spacer;
  :text
    {
    label="Slopes are parallel !";
    }
  spacer;
  ok_only;
}

string: dialog
{
label="String Editor";
  :boxed_column
    {
    :button
      {
      key="new";
      label="  NEW<<<  ";
      mnemonic="N";
      }
    :boxed_radio_row
      {
      key="c";
      value="open";
      :radio_button
       {
        key="open";
        label="Open";
        }
      :radio_button
        {
        key="closed";
        label="Closed";
        }
      }
    }
  spacer;
  spacer;
    :column
      {
      :row    
        {
        children_alignment=bottom;
        :button
          {
          key="show";
          label=" SHOW<<<  ";
          mnemonic="S";
          width=20;
          }
        :button
          {
          key="3dpoly";
          label="3DPOLY<<< ";
          mnemonic="3";
          width=20;
          }
        }
      :row    
        {
        children_alignment=bottom;
        :button
          {
          key="layer";
          label=" LAYER ";
          mnemonic="L";
          width=20;
          }
        :button
          {
          key="2dpoly";
          label="2DPOLY<<< ";
          mnemonic="2";
          width=20;
          }
        }
      :row
        {
        :button
          {
          key="copy";
          label=" COPY...  ";
          mnemonic="C";
          width=20;
          }
        :button
          {
          key="break";
          label=" BREAK<<< ";
          mnemonic="B";
          width=20;
          }
        }
      :row
        {
        :button
          {
          key="reverse";
          label="REVERSE...";
          mnemonic="R";
          width=20;
          }
        :button
          {
          key="join";
          label=" JOIN...  ";
          mnemonic="J";
          width=3;
          width=20;    
          }
        }
      }
spacer;
ok_cancel;
}

layer:dialog
{
label="New layer for string points";
  :popup_list
    {
    key="layer";
    label="Layer:";
    edit_width=20;
    }
ok_cancel;
}

surarea : dialog
{
  width=30;
  label="Surface Area";
  spacer;
  :text
    {
    key="name";
    label="                                          ";
    }
  spacer;
  spacer;
  :text
    {
    key="hor";
    label="                                          ";
    }
  :text
    {
    key="slant";
    label="                                          ";
    }
  :text
    {
    key="war";
    label="                                          ";
    }
  spacer;
  ok_only;
}