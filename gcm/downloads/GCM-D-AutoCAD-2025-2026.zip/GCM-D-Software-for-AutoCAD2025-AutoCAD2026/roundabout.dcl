ROUNDLEG:dialog{
label ="Roundabout - Leg Parameters";
:row{ // GAVRAN plus From FILE
    :image_button
      {
      alignment=right;
      color=-15;
      fixed_width=true;
      fixed_height=true;
      key="gavran";
      width=16;
      height=5;
      }
    :button{key="FF";fixed_width=true;label="From File <";mnemonic="f";}
}    // end of GAVRAN plus From FILE
:boxed_row{ // central ROW
  :boxed_column{
          :column{
                 children_alignment=centered;
                 fixed_height=true;
                 :edit_box{key="DA";edit_width=5;fixed_width=true;label="Deflection Angle (Alpha) in grads:";mnemonic="D";}
                 :edit_box{key="SW";edit_width=5;fixed_width=true;label="                      Splitter Zone Width (S):";mnemonic="Z";}
                 }
          :row{
              :column{
                     fixed_height=true;
                     children_alignment=right;
                     :edit_box{key="RXS";edit_width=5;fixed_width=true;label="Exit Radius Smaller (RXS):";mnemonic="E";}
                     :edit_box{key="RXL";edit_width=5;fixed_width=true;label="Exit Radius Larger (RXL):";mnemonic="R";}
                     :edit_box{key="WX";edit_width=5;fixed_width=true;label="Exit Width (WX):";mnemonic="x";}
                     }
              :image_button
                     {
                     alignment=right;
                     color=-15;
                     fixed_width=true;
                     fixed_height=true;
                     key="roundabout-leg";
                     width=34;
                     height=18;
                     }
              :column{
                     fixed_height=true;
                     children_alignment=right;
                     :edit_box{key="RES";edit_width=5;fixed_width=true;label="Entrance Radius Smaller (RES):";mnemonic="S";}
                     :edit_box{key="REL";edit_width=5;fixed_width=true;label="Entrance Radius Larger (REL):";mnemonic="L";}
                     :edit_box{key="WE";edit_width=5;fixed_width=true;label="Entrance Width (WE):";mnemonic="W";}
                     }
              }
          :edit_box{key="BI";alignment=centered;edit_width=5;fixed_width=true;label="Basic Isle Width:";mnemonic="I";}
          :text{label="   ";}
         }
  :boxed_column{ // Right Column
        :row{
            :column{
                   fixed_height=true;
                   children_alignment=right;
                   :edit_box{key="RL";edit_width=5;fixed_width=true;label="Approach Nose Radius (RL):";mnemonic="A";}
                   :edit_box{key="OL";edit_width=5;fixed_width=true;label="Approach Nose Offset (OL):";mnemonic="O";}
                   }
            :column{
                   fixed_height=true;
                   children_alignment=right;
                   :edit_box{key="RS";edit_width=5;fixed_width=true;label="Smaller Nose Radius (RS):";mnemonic="N";}
                   :edit_box{key="OS";edit_width=5;fixed_width=true;label="Smaller Nose Offset (OS):";mnemonic="f";}
                   }
            }
            :image_button
                   {
                   alignment=right;
                   color=-15;
                   fixed_width=true;
                   fixed_height=true;
                   key="roundabout-isle";
                   width=34;
                   height=18;
                   }
        :column{
               fixed_height=true;
               children_alignment=right;
               :edit_box{key="RM";edit_width=5;fixed_width=true;label="Intermediate Nose Radius (RI):";mnemonic="I";}
               :edit_box{key="OM";edit_width=5;fixed_width=true;label="Intermediate Nose Offset (OI):";mnemonic="m";}
               }
         } // ENd of rRight Column
}    // end of central ROW
spacer_1;
ok_cancel;
}

ROUNDCIRC:dialog{
label ="Roundabout - Circular Roadway Dimensions";
:row // ROW 1
{
:column{ // ROW2 + ROW3
:boxed_row // ROW 2
{
:column{
    children_alignment=right;
    spacer_0;
    :text{label="Inscribed Diameter";}
    :text{label="Single Lane Pavement Width (SLPW)";}
    :text{label="Reduced SLPW - Apron Truck to be Added";}
    :text{label="Double Lane Pavement Width";}
    }
:column{
    :edit_box{key="D1";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-1";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-1";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-1";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D2";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-2";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-2";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-2";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D3";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-3";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-3";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-3";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D4";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-4";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-4";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-4";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D5";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-5";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-5";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-5";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D6";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-6";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-6";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-6";edit_width=5;fixed_width=true;}
    }
} // END of ROW 2
:boxed_row // ROW 3
{
:column{
    children_alignment=right;
    spacer_0;
    :text{label="Inscribed Diameter";}
    :text{label="Single Lane Pavement Width (SLPW)";}
    :text{label="Reduced SLPW - Apron Truck to be Added";}
    :text{label="Double Lane Pavement Width";}
    }
:column{
    :edit_box{key="D7";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-7";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-7";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-7";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D8";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-8";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-8";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-8";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D9";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-9";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-9";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-9";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D10";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-10";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-10";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-10";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D11";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-11";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-11";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-11";edit_width=5;fixed_width=true;}
    }
:column{
    :edit_box{key="D12";edit_width=5;fixed_width=true;}
    :edit_box{key="w1-12";edit_width=5;fixed_width=true;}
    :edit_box{key="w1a-12";edit_width=5;fixed_width=true;}
    :edit_box{key="w2-12";edit_width=5;fixed_width=true;}
    }
} // END of ROW 3
} // END column ROW2+ROW3 
:column{ // right column 
    spacer_1;
    :image_button
      {
      alignment=right;
      color=-15;
      fixed_width=true;
      fixed_height=true;
      key="gavran";
      width=16;
      height=5;
      }
:boxed_column
{
children_alignment=right;
:text{label="_____Parameters to be Deployed_____";}
:edit_box{key="D";edit_width=5;fixed_width=true;label="Inscribed Diameter=";mnemonic="d";}
:edit_box{key="W";edit_width=5;fixed_width=true;label="Circular Roadway Width=";mnemonic="w";}
:edit_box{key="A";edit_width=5;fixed_width=true;label="Truck Apron=";mnemonic="a";}
}
} // END of right column
} // END of the ROW 1
spacer_1;
ok_cancel;
}