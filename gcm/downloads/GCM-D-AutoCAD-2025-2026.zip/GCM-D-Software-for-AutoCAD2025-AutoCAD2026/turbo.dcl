TURBOLEG:dialog{
label ="TURBO Roundabout - Leg Parameters";
:boxed_row{ 
  :boxed_column{
          label="Traffic Lanes and Radii";
          children_alignment=centered;
          :row{
              :column{
                     fixed_height=true;
                     children_alignment=right;
                     :edit_box{key="RE";edit_width=5;fixed_width=true;label="Entrance Radius (RE):";mnemonic="R";}
                     :edit_box{key="RX";edit_width=5;fixed_width=true;label="Exit Radius (RX):";mnemonic="x";}
                     :edit_box{key="RT";edit_width=5;fixed_width=true;label="Turn Radius (RT):";mnemonic="T";}
                     }
              :image_button
                     {
                     alignment=right;
                     color=-15;
                     fixed_width=true;
                     fixed_height=true;
                     key="turbo-leg";
                     width=60;
                     height=24;
                     }
               :text{label="              ";}
              }
          :boxed_row{
          label="Number of Traffic Lanes";
          :column{
          :boxed_radio_row{
                 fixed_width=true;
                 children_alignment=centered;
                 label="Number of Exit Lanes";
                 :radio_button{key="X1";label="1 Lane:";mnemonic="1";}
                 :radio_button{key="X2";label="2 Lanes:";mnemonic="2";}
                 :radio_button{key="X3";label="3 Lanes:";mnemonic="3";}
                 }
                 :edit_box{key="XL";edit_width=5;fixed_width=true;label="Exit Lane width (WX):";mnemonic="x";}
          }
          :column{
          :boxed_radio_row{
                 fixed_width=true;
                 children_alignment=centered;
                 label="Number of Entrance Lanes";
                 :radio_button{key="E1";label="1 Lane:";mnemonic="1";}
                 :radio_button{key="E2";label="2 Lanes:";mnemonic="2";}
                 :radio_button{key="E3";label="3 Lanes:";mnemonic="3";}
                 }
                 :edit_box{key="EL";edit_width=5;fixed_width=true;label="Entrance Lane width (WE):";mnemonic="L";}
          }
          }
         }
  :boxed_column{ // Right Column
        :row{
            :column{
                   fixed_height=true;
                   children_alignment=right;
                   :edit_box{key="EX";edit_width=5;fixed_width=true;label="Exit - Edge Lane along Divider (EX):";mnemonic="X";}
                   :edit_box{key="ED";edit_width=5;fixed_width=true;label="Exit - Divider Width (ED):";mnemonic="D";}
                   }
            :column{
                   fixed_height=true;
                   children_alignment=right;
                   :edit_box{key="RN";edit_width=5;fixed_width=true;label="Nose Radius (RN):";mnemonic="N";}
                   :edit_box{key="SO";edit_width=5;fixed_width=true;label="Splitter Island Offset (SO):";mnemonic="f";}
                   }
            }
            :image_button
                   {
                   alignment=right;
                   color=-15;
                   fixed_width=true;
                   fixed_height=true;
                   key="turbo-det";
                   width=60;
                   height=23;
                   }
        :column{
               fixed_height=true;
               children_alignment=right;
               :edit_box{key="SE";edit_width=5;fixed_width=true;label="Splitter Island Half-width / Entrance Side (SE):";mnemonic="S";}
               :edit_box{key="SX";edit_width=5;fixed_width=true;label="Splitter Island Half-width / Exit Side (SX):";mnemonic="H";}
               }
         } 
}   
spacer_1;
ok_cancel;
}
 